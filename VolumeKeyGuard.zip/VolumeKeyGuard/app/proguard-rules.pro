# Hook 类通过反射被框架调用，禁止混淆
-keep class com.volumeguard.xp.hook.** { *; }
-keep class com.volumeguard.xp.core.** { *; }
-keep class com.volumeguard.xp.ui.ModuleStatus { *; }
-keep class de.robv.android.xposed.** { *; }
