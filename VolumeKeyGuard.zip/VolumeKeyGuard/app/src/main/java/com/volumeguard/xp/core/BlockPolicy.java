package com.volumeguard.xp.core;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

/**
 * 拦截决策的唯一事实来源（纯逻辑，无 Android 依赖）。
 *
 * <p>Hook 端每次决策前从 {@link com.volumeguard.xp.hook.ConfigBridge} 取得最新实例；
 * UI 端通过 {@link #fromMap(Map)} 构造用于预览。实例不可变，线程安全。
 */
public final class BlockPolicy {

    /** 缺省拦截集：音量加 / 音量减 / 静音。 */
    public static final Set<Integer> DEFAULT_KEYS =
            Collections.unmodifiableSet(new HashSet<>(Arrays.asList(24, 25, 164)));

    public final boolean enabled;
    public final Set<Integer> keys;
    public final Set<String> apps;

    public BlockPolicy(boolean enabled, Set<Integer> keys, Set<String> apps) {
        this.enabled = enabled;
        this.keys = keys == null ? Collections.<Integer>emptySet() : Collections.unmodifiableSet(keys);
        this.apps = apps == null ? Collections.<String>emptySet() : Collections.unmodifiableSet(apps);
    }

    /** 从配置 Map 构造；map 为 null 时返回安全的全关策略。 */
    public static BlockPolicy fromMap(Map<String, String> map) {
        if (map == null) return new BlockPolicy(false, null, null);
        boolean enabled = "1".equals(map.get("enabled"));
        Set<Integer> keys = parseIntSet(map.get("keys"));
        if (keys.isEmpty() && !map.containsKey("keys")) keys = new HashSet<>(DEFAULT_KEYS);
        Set<String> apps = parseStrSet(map.get("apps"));
        return new BlockPolicy(enabled, keys, apps);
    }

    /** 前台应用为 pkg 时，keyCode 是否应被拦截。 */
    public boolean blockKey(String pkg, int keyCode) {
        return enabled && pkg != null && apps.contains(pkg) && keys.contains(keyCode);
    }

    /** Binder 调用方（可能对应多个共享 UID 包名）是否应被静默拦截音量调用。 */
    public boolean blockVolumeCall(String[] callerPackages) {
        if (!enabled || callerPackages == null) return false;
        for (String p : callerPackages) {
            if (p != null && apps.contains(p)) return true;
        }
        return false;
    }

    private static Set<Integer> parseIntSet(String csv) {
        Set<Integer> set = new LinkedHashSet<>();
        if (csv == null) return set;
        for (String s : csv.split(",")) {
            String t = s.trim();
            if (t.isEmpty()) continue;
            try { set.add(Integer.parseInt(t)); } catch (NumberFormatException ignored) {}
        }
        return set;
    }

    private static Set<String> parseStrSet(String csv) {
        Set<String> set = new LinkedHashSet<>();
        if (csv == null) return set;
        for (String s : csv.split(",")) {
            String t = s.trim();
            if (!t.isEmpty()) set.add(t);
        }
        return set;
    }
}
