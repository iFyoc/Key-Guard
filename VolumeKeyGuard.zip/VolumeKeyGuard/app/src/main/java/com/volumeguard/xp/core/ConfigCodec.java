package com.volumeguard.xp.core;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 行式 key=value 配置编解码。
 *
 * <p>配置以单个字符串形式写入 SharedPreferences（键 {@code raw}），
 * Hook 端通过 XSharedPreferences 读取后用本类解析，UI 端与 Hook 端共用，
 * 不依赖任何 Android 类，可本地单测。
 *
 * <p>格式约定：
 * <ul>
 *   <li>每行 {@code key=value}，以第一个 {@code '='} 分割，value 可含 '='、可为空</li>
 *   <li>空行与 '#' 开头的注释行忽略</li>
 *   <li>encode 跳过 value 为 null 的条目</li>
 * </ul>
 */
public final class ConfigCodec {
    private ConfigCodec() {}

    public static String encode(Map<String, String> map) {
        StringBuilder sb = new StringBuilder();
        if (map != null) {
            for (Map.Entry<String, String> e : map.entrySet()) {
                if (e.getKey() == null || e.getValue() == null) continue;
                if (e.getKey().indexOf('\n') >= 0) continue; // 防御：键不允许换行
                sb.append(e.getKey()).append('=').append(e.getValue().replace("\n", " ")).append('\n');
            }
        }
        return sb.toString();
    }

    public static Map<String, String> decode(String raw) {
        Map<String, String> out = new LinkedHashMap<>();
        if (raw == null || raw.isEmpty()) return out;
        for (String line : raw.split("\n")) {
            String t = line.trim();
            if (t.isEmpty() || t.charAt(0) == '#') continue;
            int eq = t.indexOf('=');
            if (eq <= 0) continue; // 无 '=' 或键为空 → 脏数据，忽略
            out.put(t.substring(0, eq).trim(), t.substring(eq + 1).trim());
        }
        return out;
    }
}
