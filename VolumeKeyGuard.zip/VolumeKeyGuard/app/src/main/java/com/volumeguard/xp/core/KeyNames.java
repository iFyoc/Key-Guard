package com.volumeguard.xp.core;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * KEYCODE 名称与数值互转（纯逻辑，UI 添加按键与配置解析共用）。
 * 常用按键内置中文名，便于 UI 直接展示。
 */
public final class KeyNames {
    private KeyNames() {}

    public static final class Preset {
        public final int code;
        public final String name;
        public final String label;
        public Preset(int code, String name, String label) {
            this.code = code; this.name = name; this.label = label;
        }
        @Override public String toString() { return label + " (" + name + ")"; }
    }

    /** 常用按键表（顺序即 UI 展示顺序，音量三键置顶）。 */
    private static final Map<Integer, String[]> COMMON = new LinkedHashMap<>();
    static {
        // code → {常量名, 中文标签}
        COMMON.put(24,  new String[]{"KEYCODE_VOLUME_UP", "音量 +"});
        COMMON.put(25,  new String[]{"KEYCODE_VOLUME_DOWN", "音量 -"});
        COMMON.put(164, new String[]{"KEYCODE_VOLUME_MUTE", "静音"});
        COMMON.put(168, new String[]{"KEYCODE_MEDIA_AUDIO_TRACK", "音轨切换"});
        COMMON.put(26,  new String[]{"KEYCODE_POWER", "电源键"});
        COMMON.put(4,   new String[]{"KEYCODE_BACK", "返回键"});
        COMMON.put(3,   new String[]{"KEYCODE_HOME", "Home 键"});
        COMMON.put(187, new String[]{"KEYCODE_APP_SWITCH", "多任务键"});
        COMMON.put(27,  new String[]{"KEYCODE_CAMERA", "相机键"});
        COMMON.put(85,  new String[]{"KEYCODE_MEDIA_PLAY_PAUSE", "播放/暂停"});
        COMMON.put(86,  new String[]{"KEYCODE_MEDIA_STOP", "媒体停止"});
        COMMON.put(87,  new String[]{"KEYCODE_MEDIA_NEXT", "下一曲"});
        COMMON.put(88,  new String[]{"KEYCODE_MEDIA_PREVIOUS", "上一曲"});
        COMMON.put(120, new String[]{"KEYCODE_SYSRQ", "截屏/调试键"});
    }

    private static final Map<String, Integer> NAME_TO_CODE = new LinkedHashMap<>();
    static {
        for (Map.Entry<Integer, String[]> e : COMMON.entrySet()) NAME_TO_CODE.put(e.getValue()[0], e.getKey());
    }

    /**
     * 解析用户输入：支持 "KEYCODE_VOLUME_UP"、"24"、带空格形式；无法识别返回 -1。
     */
    public static int toCode(String nameOrNumber) {
        if (nameOrNumber == null) return -1;
        String s = nameOrNumber.trim();
        if (s.isEmpty()) return -1;
        Integer byName = NAME_TO_CODE.get(s);
        if (byName != null) return byName;
        try {
            int v = Integer.parseInt(s);
            return v >= 0 ? v : -1;
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    /** 数值转常量名；未知 code 返回 "KEYCODE_<code>" 占位。 */
    public static String toName(int code) {
        String[] v = COMMON.get(code);
        return v != null ? v[0] : ("KEYCODE_" + code);
    }

    public static List<Preset> commonPresets() {
        List<Preset> list = new ArrayList<>();
        for (Map.Entry<Integer, String[]> e : COMMON.entrySet()) {
            list.add(new Preset(e.getKey(), e.getValue()[0], e.getValue()[1]));
        }
        return list;
    }
}
