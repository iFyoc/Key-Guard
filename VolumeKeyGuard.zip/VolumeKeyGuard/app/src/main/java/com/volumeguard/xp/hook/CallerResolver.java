package com.volumeguard.xp.hook;

import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

import android.os.Binder;

import java.util.HashMap;
import java.util.Map;

/**
 * Binder 调用方 UID → 包名解析（system_server 内使用），带小型缓存。
 * 系统级 UID（<10000，含 system/root/phone/bluetooth）直接返回 null：
 * 这些调用永远不拦截，保证系统自身音量逻辑（如按键路径、铃声）不受影响。
 */
public final class CallerResolver {

    private static final String TAG = "[VolumeKeyGuard] ";
    private static final int APP_UID_START = 10000;
    private static final int CACHE_MAX = 512;

    private static final Map<Integer, String[]> CACHE = new HashMap<>();

    private CallerResolver() {}

    /** 当前 Binder 调用方的包名集合；系统调用或解析失败返回 null（= 不拦截）。 */
    public static String[] packagesForCallingUid() {
        int uid;
        try {
            uid = Binder.getCallingUid();
        } catch (Throwable t) {
            return null;
        }
        if (uid < APP_UID_START) return null;

        synchronized (CACHE) {
            String[] hit = CACHE.get(uid);
            if (hit != null) return hit.length == 0 ? null : hit;
        }

        String[] pkgs = null;
        try {
            Class<?> at = XposedHelpers.findClass("android.app.ActivityThread", null);
            Object pm = XposedHelpers.callStaticMethod(at, "getPackageManager");
            Object result = XposedHelpers.callMethod(pm, "getPackagesForUid", uid);
            if (result instanceof String[]) pkgs = (String[]) result;
        } catch (Throwable t) {
            XposedBridge.log(TAG + "packagesForUid(" + uid + ") failed: " + t);
        }

        synchronized (CACHE) {
            if (CACHE.size() >= CACHE_MAX) CACHE.clear();
            CACHE.put(uid, pkgs == null ? new String[0] : pkgs);
        }
        return pkgs;
    }
}
