package com.volumeguard.xp.hook;

import com.volumeguard.xp.core.BlockPolicy;
import com.volumeguard.xp.core.ConfigCodec;

import de.robv.android.xposed.XSharedPreferences;
import de.robv.android.xposed.XposedBridge;

import java.util.Map;

/**
 * Hook 端配置桥：读取模块 App 写入的 SharedPreferences（键 "raw"，行式 key=value 文本），
 * 解析为不可变的 {@link BlockPolicy}，带 TTL 缓存实现"改完即生效"的热更新。
 *
 * <p>运行在 system_server / SystemUI 等高权限进程内，XSharedPreferences 在 LSPosed
 * 环境下可读；读取失败时降级为全关策略（绝不拦截），保证不误伤系统。
 */
public final class ConfigBridge {

    public static final String MODULE_PKG = "com.volumeguard.xp";
    public static final String PREFS_NAME = "vkguard_prefs";
    public static final String KEY_RAW = "raw";

    /** 配置重载最小间隔（毫秒），按键事件高频，避免每次决策都读盘。 */
    private static final long RELOAD_TTL_MS = 1500L;

    private static final Object LOCK = new Object();
    private static volatile ConfigBridge sInstance;

    private final XSharedPreferences prefs;
    private volatile BlockPolicy cached = new BlockPolicy(false, null, null);
    private volatile long lastReloadAt = 0L;

    public static ConfigBridge get() {
        ConfigBridge b = sInstance;
        if (b == null) {
            synchronized (LOCK) {
                b = sInstance;
                if (b == null) {
                    b = new ConfigBridge();
                    sInstance = b;
                }
            }
        }
        return b;
    }

    private ConfigBridge() {
        prefs = new XSharedPreferences(MODULE_PKG, PREFS_NAME);
        // 老框架（EdXposed 等）需要 world-readable；LSPosed 下该调用无害
        try { prefs.makeWorldReadable(); } catch (Throwable ignored) {}
        reloadNow();
    }

    /** 取得当前拦截策略；超过 TTL 自动重载。任何异常都降级为不拦截。 */
    public BlockPolicy getPolicy() {
        long now = System.currentTimeMillis();
        if (now - lastReloadAt > RELOAD_TTL_MS) {
            reloadNow();
        }
        return cached;
    }

    private void reloadNow() {
        lastReloadAt = System.currentTimeMillis();
        try {
            prefs.reload();
            String raw = prefs.getString(KEY_RAW, "");
            Map<String, String> map = ConfigCodec.decode(raw);
            cached = BlockPolicy.fromMap(map);
        } catch (Throwable t) {
            XposedBridge.log("[VolumeKeyGuard] config reload failed: " + t);
            cached = new BlockPolicy(false, null, null);
        }
    }
}
