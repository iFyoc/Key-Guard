package com.volumeguard.xp.hook;

import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

import android.content.ComponentName;
import android.content.Intent;

/**
 * 前台包名探测。两条路径，全部只在系统进程内反射，失败静默返回 null（= 不拦截）：
 *
 * <ol>
 *   <li>system_server：从 PhoneWindowManager 实例摸到 WindowManagerService.mCurrentFocus
 *       （WindowState），取 owningPackage / mAttrs.packageName —— 按键拦截走这条，零延迟。</li>
 *   <li>任意系统进程：ActivityTaskManager.getService().getFocusedRootTaskInfo()
 *       → topActivity / baseIntent —— SystemUI 音量面板抑制走这条，带短 TTL 缓存。</li>
 * </ol>
 */
public final class ForegroundWatch {

    private static final String TAG = "[VolumeKeyGuard] ";
    private static final long ATM_CACHE_TTL_MS = 300L;

    private static volatile String sAtmCachedPkg;
    private static volatile long sAtmCachedAt;

    private ForegroundWatch() {}

    /** 路径①：system_server 内，基于 PhoneWindowManager thisObject。 */
    public static String fromPhoneWindowManager(Object pwm) {
        try {
            Object wms = null;
            try {
                wms = XposedHelpers.getObjectField(pwm, "mWindowManager");
            } catch (Throwable ignored) {}
            if (wms == null) {
                try {
                    Class<?> wmg = XposedHelpers.findClass("android.view.WindowManagerGlobal", null);
                    wms = XposedHelpers.callStaticMethod(wmg, "getWindowManagerService");
                } catch (Throwable ignored) {}
            }
            if (wms != null) {
                Object focus = XposedHelpers.getObjectField(wms, "mCurrentFocus");
                String pkg = packageOfWindowState(focus);
                if (pkg != null) return pkg;
            }
        } catch (Throwable t) {
            XposedBridge.log(TAG + "fromPhoneWindowManager failed: " + t);
        }
        // 兜底走 ATM
        return currentViaAtm();
    }

    private static String packageOfWindowState(Object windowState) {
        if (windowState == null) return null;
        try {
            Object pkg = XposedHelpers.callMethod(windowState, "getOwningPackage");
            if (pkg instanceof String && !((String) pkg).isEmpty()) return (String) pkg;
        } catch (Throwable ignored) {}
        try {
            Object attrs = XposedHelpers.getObjectField(windowState, "mAttrs");
            Object pkg = XposedHelpers.getObjectField(attrs, "packageName");
            if (pkg instanceof String && !((String) pkg).isEmpty()) return (String) pkg;
        } catch (Throwable ignored) {}
        return null;
    }

    /** 路径②：任意系统进程，经 ActivityTaskManager 取焦点任务栈顶包名，带 TTL 缓存。 */
    public static String currentViaAtm() {
        long now = System.currentTimeMillis();
        String cached = sAtmCachedPkg;
        if (cached != null && now - sAtmCachedAt < ATM_CACHE_TTL_MS) return cached;
        String pkg = null;
        try {
            Class<?> atmClz = XposedHelpers.findClass("android.app.ActivityTaskManager", null);
            Object atm = XposedHelpers.callStaticMethod(atmClz, "getService");
            Object info = XposedHelpers.callMethod(atm, "getFocusedRootTaskInfo");
            if (info != null) {
                try {
                    Object top = XposedHelpers.getObjectField(info, "topActivity");
                    if (top instanceof ComponentName) pkg = ((ComponentName) top).getPackageName();
                } catch (Throwable ignored) {}
                if (pkg == null) {
                    try {
                        Object baseIntent = XposedHelpers.getObjectField(info, "baseIntent");
                        if (baseIntent instanceof Intent) {
                            ComponentName comp = ((Intent) baseIntent).getComponent();
                            if (comp != null) pkg = comp.getPackageName();
                        }
                    } catch (Throwable ignored) {}
                }
            }
        } catch (Throwable t) {
            XposedBridge.log(TAG + "currentViaAtm failed: " + t);
        }
        if (pkg != null) {
            sAtmCachedPkg = pkg;
            sAtmCachedAt = now;
        }
        return pkg;
    }
}
