package com.volumeguard.xp.hook;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * 模块入口（assets/xposed_init 指向本类）。
 *
 * <p>只装载进三个进程：
 * <ul>
 *   <li>{@code android}（system_server）→ {@link SystemServerHook}：按键/音量调用/音量条拦截</li>
 *   <li>{@code com.android.systemui} → {@link SystemUIHook}：音量面板防御层</li>
 *   <li>模块自身 → 激活状态标记（UI 显示"模块已生效"）</li>
 * </ul>
 * 目标应用进程<b>不被装载</b>，无法感知模块存在。
 */
public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "[VolumeKeyGuard] ";

    @Override
    public void handleLoadPackage(final IXposedHookLoadPackage.LoadPackageParam lpparam) {
        if ("android".equals(lpparam.packageName)) {
            SystemServerHook.init(lpparam.classLoader);

        } else if ("com.android.systemui".equals(lpparam.packageName)) {
            SystemUIHook.init(lpparam.classLoader);

        } else if (ConfigBridge.MODULE_PKG.equals(lpparam.packageName)) {
            hookModuleActiveFlag(lpparam.classLoader);
        }
    }

    /** 把 ModuleStatus.isModuleActive() 恒置 true，供 UI 显示激活状态。 */
    private static void hookModuleActiveFlag(ClassLoader cl) {
        try {
            Class<?> status = XposedHelpers.findClass("com.volumeguard.xp.ui.ModuleStatus", cl);
            XposedHelpers.findAndHookMethod(status, "isModuleActive", new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) {
                    param.setResult(true);
                }
            });
        } catch (Throwable t) {
            XposedBridge.log(TAG + "hookModuleActiveFlag failed: " + t);
        }
    }
}
