package com.volumeguard.xp.hook;

import com.volumeguard.xp.core.BlockPolicy;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

import android.view.KeyEvent;

import java.lang.reflect.Method;

/**
 * system_server 侧拦截（模块核心，目标应用进程内不装任何 Hook）：
 *
 * <ol>
 *   <li>物理按键：PhoneWindowManager#interceptKeyBeforeQueueing /
 *       interceptKeyBeforeDispatching —— 前台应用命中黑名单时事件在入队前被丢弃，
 *       目标应用与系统音量面板都收不到，应用侧完全无感知。</li>
 *   <li>程序调用：AudioService 的全部音量写入方法 —— 按 Binder.getCallingUid()
 *       归属包名判断，命中则静默 no-op（方法正常返回，音量不变，无异常）。</li>
 *   <li>音量条 UI：AudioService#showSystemUI / postShowSystemUI ——
 *       来源为黑名单应用时不弹系统音量面板。</li>
 * </ol>
 *
 * 兼容性策略：所有 hook 均包 try/catch 并写 Xposed 日志；方法签名跨版本差异用
 * hookAllMethods + 运行时判断返回类型消化；任何一步失败只降级该层，不影响其余层。
 */
public final class SystemServerHook {

    private static final String TAG = "[VolumeKeyGuard] ";

    /** AudioService 中需要静默拦截的音量写入方法（存在才 hook，不存在跳过）。 */
    private static final String[] VOLUME_WRITE_METHODS = {
            "adjustSuggestedStreamVolume",
            "adjustStreamVolume",
            "adjustMasterVolume",
            "setStreamVolume",
            "setStreamVolumeWithAttribution",
            "setStreamVolumeIndex",
            "setMasterVolume",
            "setStreamVolumeForced",
    };

    private static final String[] UI_METHODS = {
            "showSystemUI",
            "postShowSystemUI",
    };

    private SystemServerHook() {}

    public static void init(ClassLoader systemCl) {
        XposedBridge.log(TAG + "system_server hooks installing...");
        hookPhoneWindowManager(systemCl);
        hookAudioService(systemCl);
        XposedBridge.log(TAG + "system_server hooks done.");
    }

    // ---------------------------------------------------------------- 按键

    private static void hookPhoneWindowManager(ClassLoader cl) {
        try {
            Class<?> pwm = XposedHelpers.findClass("com.android.internal.policy.PhoneWindowManager", cl);

            XC_MethodHook keyBlocker = new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) {
                    try {
                        KeyEvent event = findKeyEvent(param.args);
                        if (event == null) return;
                        BlockPolicy policy = ConfigBridge.get().getPolicy();
                        int keyCode = event.getKeyCode();
                        if (!policy.enabled || !policy.keys.contains(keyCode)) return;

                        String pkg = ForegroundWatch.fromPhoneWindowManager(param.thisObject);
                        if (!policy.blockKey(pkg, keyCode)) return;

                        // 静默吞掉：Queueing 返回 0（事件不入队）；Dispatching 返回负值（不下发）
                        Object consumed = consumedResultFor(param.method);
                        param.setResult(consumed);
                    } catch (Throwable t) {
                        XposedBridge.log(TAG + "keyBlocker failed: " + t);
                    }
                }
            };

            // interceptKeyBeforeQueueing(KeyEvent, int) —— 各版本签名稳定
            try {
                XposedHelpers.findAndHookMethod(pwm, "interceptKeyBeforeQueueing",
                        KeyEvent.class, int.class, keyBlocker);
            } catch (Throwable t) {
                XposedBridge.log(TAG + "queueing signature fallback: " + t);
                XposedBridge.hookAllMethods(pwm, "interceptKeyBeforeQueueing", keyBlocker);
            }

            // interceptKeyBeforeDispatching —— 参数类型跨版本不同（IBinder/WindowState），返回 int 或 long
            XposedBridge.hookAllMethods(pwm, "interceptKeyBeforeDispatching", keyBlocker);
        } catch (Throwable t) {
            XposedBridge.log(TAG + "hookPhoneWindowManager failed: " + t);
        }
    }

    /** 按方法真实返回类型给出"已消费"返回值。 */
    private static Object consumedResultFor(java.lang.reflect.Member member) {
        if (member instanceof Method) {
            Class<?> rt = ((Method) member).getReturnType();
            if (rt == long.class) return -1L;      // interceptKeyBeforeDispatching 新版返回 long
            if (rt == int.class) {
                return "interceptKeyBeforeQueueing".equals(member.getName()) ? 0 : -1;
            }
        }
        return null;
    }

    private static KeyEvent findKeyEvent(Object[] args) {
        if (args == null) return null;
        for (Object a : args) {
            if (a instanceof KeyEvent) return (KeyEvent) a;
        }
        return null;
    }

    // ---------------------------------------------------------------- 音量调用 & UI

    private static void hookAudioService(ClassLoader cl) {
        try {
            Class<?> audioService = XposedHelpers.findClass("android.media.AudioService", cl);

            XC_MethodHook volumeBlocker = new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) {
                    try {
                        BlockPolicy policy = ConfigBridge.get().getPolicy();
                        if (!policy.enabled) return;
                        String[] pkgs = CallerResolver.packagesForCallingUid();
                        if (!policy.blockVolumeCall(pkgs)) return;
                        // 静默 no-op：void→null，int→0，其余→null，方法"正常返回"
                        param.setResult(defaultResultFor(param.method));
                    } catch (Throwable t) {
                        XposedBridge.log(TAG + "volumeBlocker failed: " + t);
                    }
                }
            };

            for (String m : VOLUME_WRITE_METHODS) {
                try {
                    XposedBridge.hookAllMethods(audioService, m, volumeBlocker);
                } catch (Throwable ignored) { /* 该方法在此版本不存在 */ }
            }

            XC_MethodHook uiBlocker = new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) {
                    try {
                        BlockPolicy policy = ConfigBridge.get().getPolicy();
                        if (!policy.enabled) return;
                        String[] pkgs = CallerResolver.packagesForCallingUid();
                        if (policy.blockVolumeCall(pkgs)) param.setResult(null);
                    } catch (Throwable t) {
                        XposedBridge.log(TAG + "uiBlocker failed: " + t);
                    }
                }
            };
            for (String m : UI_METHODS) {
                try {
                    XposedBridge.hookAllMethods(audioService, m, uiBlocker);
                } catch (Throwable ignored) {}
            }
        } catch (Throwable t) {
            XposedBridge.log(TAG + "hookAudioService failed: " + t);
        }
    }

    private static Object defaultResultFor(java.lang.reflect.Member member) {
        if (member instanceof Method) {
            Class<?> rt = ((Method) member).getReturnType();
            if (rt == int.class) return 0;
            if (rt == boolean.class) return false;
            if (rt == long.class) return 0L;
        }
        return null; // void 及引用类型
    }
}
