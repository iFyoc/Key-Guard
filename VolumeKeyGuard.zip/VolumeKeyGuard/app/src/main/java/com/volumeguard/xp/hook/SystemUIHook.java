package com.volumeguard.xp.hook;

import com.volumeguard.xp.core.BlockPolicy;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * SystemUI 进程侧的防御层：即便个别 ROM 的音量面板绕过了 AudioService.showSystemUI
 * 路径（如厂商自绘 VolumeDialog），在 VolumeDialogControllerImpl 的回调入口再拦一道。
 *
 * <p>前台包名经 {@link ForegroundWatch#currentViaAtm()} 获取（带 TTL 缓存），
 * 判断失败一律放行——宁可漏拦，不可误伤系统 UI。
 */
public final class SystemUIHook {

    private static final String TAG = "[VolumeKeyGuard] ";

    private SystemUIHook() {}

    public static void init(ClassLoader cl) {
        try {
            Class<?> vdc = XposedHelpers.findClass(
                    "com.android.systemui.volume.VolumeDialogControllerImpl", cl);

            XC_MethodHook suppress = new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) {
                    try {
                        BlockPolicy policy = ConfigBridge.get().getPolicy();
                        if (!policy.enabled) return;
                        String pkg = ForegroundWatch.currentViaAtm();
                        if (pkg != null && policy.apps.contains(pkg)) {
                            param.setResult(null); // 静默丢弃 show 请求
                        }
                    } catch (Throwable t) {
                        XposedBridge.log(TAG + "systemui suppress failed: " + t);
                    }
                }
            };

            // 回调实现在内部类（CallbackImpl 等），名称跨版本不稳定 → 按名称模糊匹配
            int hooked = 0;
            for (Class<?> inner : vdc.getDeclaredClasses()) {
                if (!inner.getName().contains("Callback")) continue;
                try {
                    XposedBridge.hookAllMethods(inner, "onShowRequested", suppress);
                    hooked++;
                } catch (Throwable ignored) {}
            }
            // 兜底：直接 hook 控制器自身的 show 请求入口
            try {
                XposedBridge.hookAllMethods(vdc, "show", suppress);
                hooked++;
            } catch (Throwable ignored) {}

            XposedBridge.log(TAG + "SystemUI hooks installed, entries=" + hooked);
        } catch (Throwable t) {
            // SystemUI 类结构差异极大（MIUI/ColorOS 等），失败不影响 system_server 主拦截
            XposedBridge.log(TAG + "SystemUIHook.init failed (non-fatal): " + t);
        }
    }
}
