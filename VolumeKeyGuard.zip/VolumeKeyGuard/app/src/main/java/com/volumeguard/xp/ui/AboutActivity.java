package com.volumeguard.xp.ui;

import android.os.Bundle;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.volumeguard.xp.R;

/**
 * 关于页：应用名 / 版本 / 作者（柒玥枝）/ 模块状态 / 简介与使用说明。
 * 沿用液态玻璃外观，参数与主页共享（AppConfig + AppearanceManager）。
 */
public class AboutActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        TextView version = findViewById(R.id.versionText);
        String v = "1.0.0";
        try {
            v = getPackageManager()
                    .getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception ignored) {}
        version.setText("版本 " + v);

        TextView status = findViewById(R.id.moduleStatusText);
        boolean active = ModuleStatus.isModuleActive();
        status.setText(active ? "● 模块已生效（Hook 运行中）" : "○ 模块未激活：请在 LSPosed 中启用并重启");
        status.setTextColor(active ? 0xFF6EE7A0 : 0xFFFFB4A2);

        AppConfig cfg = new AppConfig(this);
        AppearanceManager.apply(findViewById(android.R.id.content), cfg);
    }
}
