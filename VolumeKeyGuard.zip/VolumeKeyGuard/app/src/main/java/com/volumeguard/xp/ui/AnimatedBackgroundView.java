package com.volumeguard.xp.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.os.Build;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

/**
 * 液态背景：三团缓慢漂移的径向渐变光斑（蓝/紫/青），深色底。
 *
 * <p>API 31+ 时对整个背景层应用 RenderEffect 高斯模糊，半透明玻璃卡片叠在其上
 * 即呈现磨砂液态玻璃质感；模糊强度可由 UI 实时调节。低版本自动降级为柔和渐变（不模糊）。
 * 动画可开关；关闭时只绘制一帧。
 */
public class AnimatedBackgroundView extends View {

    private static final int BASE_BG = 0xFF070B18;

    private final Paint blobPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint basePaint = new Paint();

    private boolean animEnabled = true;
    private float blurPx = 0f;

    private final float[] phase = {0f, 2.1f, 4.2f};

    public AnimatedBackgroundView(Context context) { this(context, null); }
    public AnimatedBackgroundView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        basePaint.setColor(BASE_BG);
    }

    public void setAnimEnabled(boolean enabled) {
        animEnabled = enabled;
        if (enabled) {
            SystemClock.uptimeMillis();
            postInvalidateOnAnimation();
        } else {
            invalidate();
        }
    }

    /** 背景模糊（px）。仅 API 31+ 生效，经反射调用 RenderEffect，避免编译期 SDK 版本依赖。 */
    public void setBlurPx(float px) {
        blurPx = Math.max(0f, px);
        if (Build.VERSION.SDK_INT >= 31) {
            try {
                Class<?> reCls = Class.forName("android.view.RenderEffect");
                Object effect = null;
                if (blurPx > 0.5f) {
                    effect = reCls.getMethod("createBlurEffect",
                                    float.class, float.class, Shader.TileMode.class)
                            .invoke(null, blurPx, blurPx, Shader.TileMode.CLAMP);
                }
                View.class.getMethod("setRenderEffect", reCls).invoke(this, effect);
            } catch (Throwable ignored) {
                // 反射失败则降级为无模糊，不影响其余视觉效果
            }
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        canvas.drawRect(0, 0, getWidth(), getHeight(), basePaint);

        float t = animEnabled ? SystemClock.uptimeMillis() / 1000f : 3.7f;
        float w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;

        // 三团光斑：颜色 / 基准位置 / 漂移半径
        int[] colors = {0x3D5AFE, 0x8E2DE2, 0x00C6D7};
        float[][] anchors = {{0.25f, 0.22f}, {0.78f, 0.42f}, {0.42f, 0.82f}};
        float radius = Math.max(w, h) * 0.42f;

        for (int i = 0; i < 3; i++) {
            float cx = (anchors[i][0] + 0.09f * (float) Math.sin(t * 0.32f + phase[i])) * w;
            float cy = (anchors[i][1] + 0.07f * (float) Math.cos(t * 0.27f + phase[i] * 1.7f)) * h;
            int c = colors[i];
            int argb = (0x99 << 24) | (c & 0x00FFFFFF);
            blobPaint.setShader(new RadialGradient(cx, cy, radius,
                    argb, (c & 0x00FFFFFF) | 0x00000000, Shader.TileMode.CLAMP));
            canvas.drawCircle(cx, cy, radius, blobPaint);
        }

        if (animEnabled) postInvalidateOnAnimation();
    }
}
