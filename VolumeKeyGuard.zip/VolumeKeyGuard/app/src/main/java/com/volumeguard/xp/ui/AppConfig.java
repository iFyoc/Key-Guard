package com.volumeguard.xp.ui;

import android.content.Context;
import android.content.SharedPreferences;

import com.volumeguard.xp.core.ConfigCodec;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;

/**
 * UI 端配置读写：全部字段序列化为一行式 key=value 文本存入
 * SharedPreferences("vkguard_prefs") 的 "raw" 键，与 Hook 端 ConfigBridge 对齐。
 */
public class AppConfig {

    public static final String PREFS_NAME = "vkguard_prefs";
    public static final String KEY_RAW = "raw";

    // 外观默认值（液态玻璃）
    public static final float DEFAULT_BLUR = 16f;      // 背景模糊 0~30
    public static final int   DEFAULT_ALPHA = 110;     // 玻璃不透明度 30~220
    public static final float DEFAULT_CORNER = 28f;    // 圆角 dp 8~48
    public static final int   DEFAULT_HIGHLIGHT = 55;  // 边缘高光 0~100
    public static final String DEFAULT_TINT = "#1B2440";
    public static final boolean DEFAULT_ANIM = true;

    private final SharedPreferences sp;
    private Map<String, String> map;

    public AppConfig(Context ctx) {
        sp = ctx.getApplicationContext().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        map = ConfigCodec.decode(sp.getString(KEY_RAW, ""));
    }

    public void reload() {
        map = ConfigCodec.decode(sp.getString(KEY_RAW, ""));
    }

    public void save() {
        sp.edit().putString(KEY_RAW, ConfigCodec.encode(map)).apply();
    }

    // ---------------------------------------------------------------- 拦截配置

    public boolean isEnabled() {
        return "1".equals(map.get("enabled"));
    }

    public void setEnabled(boolean enabled) {
        map.put("enabled", enabled ? "1" : "0");
    }

    public LinkedHashSet<Integer> getKeys() {
        LinkedHashSet<Integer> set = new LinkedHashSet<>();
        String csv = map.get("keys");
        if (csv != null) {
            for (String s : csv.split(",")) {
                try { set.add(Integer.parseInt(s.trim())); } catch (Exception ignored) {}
            }
        }
        if (set.isEmpty() && csv == null) { set.addAll(com.volumeguard.xp.core.BlockPolicy.DEFAULT_KEYS); }
        return set;
    }

    public void setKeys(LinkedHashSet<Integer> keys) {
        StringBuilder sb = new StringBuilder();
        for (Integer k : keys) {
            if (sb.length() > 0) sb.append(',');
            sb.append(k);
        }
        map.put("keys", sb.toString());
    }

    public LinkedHashSet<String> getApps() {
        LinkedHashSet<String> set = new LinkedHashSet<>();
        String csv = map.get("apps");
        if (csv != null) {
            for (String s : csv.split(",")) {
                String t = s.trim();
                if (!t.isEmpty()) set.add(t);
            }
        }
        return set;
    }

    public void setApps(LinkedHashSet<String> apps) {
        StringBuilder sb = new StringBuilder();
        for (String a : apps) {
            if (sb.length() > 0) sb.append(',');
            sb.append(a);
        }
        map.put("apps", sb.toString());
    }

    // ---------------------------------------------------------------- 外观配置

    public float getBlur() { return parseFloat("ui_blur", DEFAULT_BLUR); }
    public void setBlur(float v) { map.put("ui_blur", String.valueOf(v)); }

    public int getAlpha() { return parseInt("ui_alpha", DEFAULT_ALPHA); }
    public void setAlpha(int v) { map.put("ui_alpha", String.valueOf(v)); }

    public float getCorner() { return parseFloat("ui_corner", DEFAULT_CORNER); }
    public void setCorner(float v) { map.put("ui_corner", String.valueOf(v)); }

    public int getHighlight() { return parseInt("ui_highlight", DEFAULT_HIGHLIGHT); }
    public void setHighlight(int v) { map.put("ui_highlight", String.valueOf(v)); }

    public String getTint() { return map.getOrDefault("ui_tint", DEFAULT_TINT); }
    public void setTint(String hex) { map.put("ui_tint", hex); }

    public boolean isAnimEnabled() { return "1".equals(map.getOrDefault("ui_anim", "1")); }
    public void setAnimEnabled(boolean v) { map.put("ui_anim", v ? "1" : "0"); }

    public void resetAppearance() {
        map.remove("ui_blur"); map.remove("ui_alpha"); map.remove("ui_corner");
        map.remove("ui_highlight"); map.remove("ui_tint"); map.remove("ui_anim");
    }

    private float parseFloat(String k, float def) {
        try { return Float.parseFloat(map.get(k)); } catch (Exception e) { return def; }
    }

    private int parseInt(String k, int def) {
        try { return Integer.parseInt(map.get(k)); } catch (Exception e) { return def; }
    }

    public static List<String> toStringList(LinkedHashSet<String> set) {
        return new ArrayList<>(set);
    }
}
