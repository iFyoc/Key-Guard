package com.volumeguard.xp.ui;

import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * 目标应用多选页：加载全部已安装应用（带图标/名称/包名），支持搜索过滤，
 * 勾选结果经 setResult 回传主页。
 */
public class AppPickerActivity extends AppCompatActivity {

    public static final String EXTRA_SELECTED = "selected";
    public static final String EXTRA_RESULT = "result";

    private final List<ApplicationInfo> allApps = new ArrayList<>();
    private final List<ApplicationInfo> shown = new ArrayList<>();
    private final Set<String> selected = new HashSet<>();

    private AppAdapter adapter;
    private PackageManager pm;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_picker);
        setTitle("选择需要拦截的应用");

        pm = getPackageManager();
        ArrayList<String> initial = getIntent().getStringArrayListExtra(EXTRA_SELECTED);
        if (initial != null) selected.addAll(initial);

        ListView list = findViewById(R.id.appList);
        adapter = new AppAdapter();
        list.setAdapter(adapter);

        EditText search = findViewById(R.id.searchBox);
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable s) { filter(s.toString()); }
        });

        Button saveBtn = findViewById(R.id.saveBtn);
        saveBtn.setOnClickListener(v -> {
            Intent data = new Intent();
            data.putStringArrayListExtra(EXTRA_RESULT, new ArrayList<>(selected));
            setResult(RESULT_OK, data);
            finish();
        });

        TextView loading = findViewById(R.id.loadingText);
        new Thread(() -> {
            List<ApplicationInfo> apps = pm.getInstalledApplications(0);
            // 用户应用排前，系统应用排后
            Collections.sort(apps, (a, b) -> {
                boolean au = (a.flags & ApplicationInfo.FLAG_SYSTEM) == 0;
                boolean bu = (b.flags & ApplicationInfo.FLAG_SYSTEM) == 0;
                if (au != bu) return au ? -1 : 1;
                return String.CASE_INSENSITIVE_ORDER.compare(
                        String.valueOf(pm.getApplicationLabel(a)),
                        String.valueOf(pm.getApplicationLabel(b)));
            });
            new Handler(Looper.getMainLooper()).post(() -> {
                allApps.addAll(apps);
                loading.setVisibility(View.GONE);
                filter("");
            });
        }).start();
    }

    private void filter(String query) {
        shown.clear();
        String q = query == null ? "" : query.trim().toLowerCase();
        for (ApplicationInfo ai : allApps) {
            if (q.isEmpty()) { shown.add(ai); continue; }
            String label = String.valueOf(pm.getApplicationLabel(ai)).toLowerCase();
            if (label.contains(q) || ai.packageName.toLowerCase().contains(q)) shown.add(ai);
        }
        adapter.notifyDataSetChanged();
    }

    private class AppAdapter extends BaseAdapter {
        @Override public int getCount() { return shown.size(); }
        @Override public Object getItem(int position) { return shown.get(position); }
        @Override public long getItemId(int position) { return position; }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View row = convertView;
            if (row == null) row = getLayoutInflater().inflate(R.layout.row_app, parent, false);
            ApplicationInfo ai = shown.get(position);

            ImageView icon = row.findViewById(R.id.appIcon);
            TextView name = row.findViewById(R.id.appName);
            TextView pkg = row.findViewById(R.id.appPkg);
            CheckBox check = row.findViewById(R.id.appCheck);

            icon.setImageDrawable(ai.loadIcon(pm));
            name.setText(pm.getApplicationLabel(ai));
            pkg.setText(ai.packageName);

            check.setOnCheckedChangeListener(null);
            check.setChecked(selected.contains(ai.packageName));
            check.setOnCheckedChangeListener((b, isChecked) -> {
                if (isChecked) selected.add(ai.packageName);
                else selected.remove(ai.packageName);
            });
            row.setOnClickListener(v -> check.setChecked(!check.isChecked()));
            return row;
        }
    }
}
