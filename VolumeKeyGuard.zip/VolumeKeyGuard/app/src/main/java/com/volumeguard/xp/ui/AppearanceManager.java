package com.volumeguard.xp.ui;

import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;

/**
 * 外观管理器：把 AppConfig 中的液态玻璃参数应用到整棵视图树，
 * 支持 SeekBar 拖动时实时刷新（无需重建 Activity）。
 */
public final class AppearanceManager {

    private AppearanceManager() {}

    public static void apply(View root, AppConfig cfg) {
        int tint;
        try {
            tint = Color.parseColor(cfg.getTint());
        } catch (Exception e) {
            tint = Color.parseColor(AppConfig.DEFAULT_TINT);
        }
        applyRecursive(root, cfg, tint);
    }

    private static void applyRecursive(View v, AppConfig cfg, int tint) {
        if (v instanceof GlassCard) {
            ((GlassCard) v).applyAppearanceDp(tint, cfg.getAlpha(), cfg.getCorner(), cfg.getHighlight());
        } else if (v instanceof AnimatedBackgroundView) {
            AnimatedBackgroundView bg = (AnimatedBackgroundView) v;
            float density = v.getResources().getDisplayMetrics().density;
            bg.setBlurPx(cfg.getBlur() * density);
            bg.setAnimEnabled(cfg.isAnimEnabled());
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                applyRecursive(g.getChildAt(i), cfg, tint);
            }
        }
    }
}
