package com.volumeguard.xp.ui;

import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;

/**
 * 外观管理器：把 AppConfig 中的液态玻璃参数应用到整棵视图树
 * （GlassCard / GlassButton / AnimatedBackgroundView），
 * 支持 SeekBar 拖动时实时刷新（无需重建 Activity）。
 */
public final class AppearanceManager {

    private AppearanceManager() {}

    public static void apply(View root, AppConfig cfg) {
        int tint;
        try {
            tint = Color.parseColor(cfg.getTint());
        } catch (Exception e) {
            tint = Color.parseColor(AppConfig.DEFAULT_TINT);
        }
        applyRecursive(root, cfg, tint);
    }

    private static void applyRecursive(View v, AppConfig cfg, int tint) {
        if (v instanceof GlassCard) {
            ((GlassCard) v).applyAppearanceDp(tint, cfg.getAlpha(), cfg.getCorner(), cfg.getHighlight());
        } else if (v instanceof GlassButton) {
            // 按钮：近透明玻璃体（取卡片透明度的三成并限幅），高光描边保留以勾勒形状
            float density = v.getResources().getDisplayMetrics().density;
            ((GlassButton) v).applyAppearance(
                    blendLighter(tint),
                    Math.max(24, Math.min(80, cfg.getAlpha() / 3)),
                    cfg.getCorner() * density * 0.55f,
                    Math.min(100, cfg.getHighlight() + 15));
        } else if (v instanceof AnimatedBackgroundView) {
            AnimatedBackgroundView bg = (AnimatedBackgroundView) v;
            float density = v.getResources().getDisplayMetrics().density;
            bg.setBlurPx(cfg.getBlur() * density);
            bg.setAnimEnabled(cfg.isAnimEnabled());
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                applyRecursive(g.getChildAt(i), cfg, tint);
            }
        }
    }

    /** 向白色方向混合 22%，让按钮玻璃体比卡片更"亮"一层。 */
    private static int blendLighter(int color) {
        int r = (color >> 16) & 0xFF, g = (color >> 8) & 0xFF, b = color & 0xFF;
        r = r + (int) ((255 - r) * 0.22f);
        g = g + (int) ((255 - g) * 0.22f);
        b = b + (int) ((255 - b) * 0.22f);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }
}
