package com.volumeguard.xp.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.AttributeSet;

import androidx.appcompat.widget.AppCompatButton;

/**
 * 液态玻璃按钮：与 GlassCard 同源的视觉语言（tint 半透明体 + 白色渐变高光描边），
 * 圆角更小的胶囊形态。外观参数可由 AppearanceManager 统一实时调节。
 */
public class GlassButton extends AppCompatButton {

    private final Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint strokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();

    private int tint = 0xFF2A3A66;
    private int alphaValue = 36;   // 近透明玻璃体，不遮挡文字
    private float cornerPx = dp(16);
    private int highlight = 70;

    public GlassButton(Context context) { this(context, null); }
    public GlassButton(Context context, AttributeSet attrs) { this(context, attrs, 0); }
    public GlassButton(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        setWillNotDraw(false);
        setBackground(null);
        setTextColor(0xFFFFFFFF);
        setAllCaps(false);
        setIncludeFontPadding(false);
        setStateListAnimator(null);
        int padH = (int) dp(18);
        int padV = (int) dp(10);
        setPadding(padH, padV, padH, padV);
        setMinHeight(0);
        setMinimumHeight(0);
    }

    /** 运行时调节外观。tint 为不透明色值，alphaValue 0~255，cornerPx 像素，highlight 0~100。 */
    public void applyAppearance(int tint, int alphaValue, float cornerPx, int highlight) {
        this.tint = tint;
        this.alphaValue = Math.max(0, Math.min(255, alphaValue));
        this.cornerPx = cornerPx;
        this.highlight = Math.max(0, Math.min(100, highlight));
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float inset = dp(1);
        rect.set(inset, inset, getWidth() - inset, getHeight() - inset);

        // 近透明玻璃体：只留很淡的一层 tint，保证文字清晰
        int a = (tint >> 24) & 0xFF;
        fillPaint.setColor((tint & 0x00FFFFFF) | ((effectiveAlpha() * a / 255) << 24));
        canvas.drawRoundRect(rect, cornerPx, cornerPx, fillPaint);

        int hi = 255 * highlight / 100;
        strokePaint.setShader(new LinearGradient(
                rect.left, rect.top, rect.right, rect.bottom,
                new int[]{(hi << 24), (hi / 3 << 24), 0x00FFFFFF},
                new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP));
        strokePaint.setStyle(Paint.Style.STROKE);
        strokePaint.setStrokeWidth(dp(1.2f));
        canvas.drawRoundRect(rect, cornerPx, cornerPx, strokePaint);

        // 关键：调用父类绘制按钮文字
        super.onDraw(canvas);
    }

    private boolean pressedState = false;

    @Override
    public void setPressed(boolean pressed) {
        super.setPressed(pressed);
        // 按压时仅提高玻璃体亮度（不动文字透明度），给出液态反馈
        pressedState = pressed;
        invalidate();
    }

    private int effectiveAlpha() {
        return pressedState ? Math.min(255, alphaValue + 50) : alphaValue;
    }

    private float dp(float v) {
        return v * getResources().getDisplayMetrics().density;
    }
}
