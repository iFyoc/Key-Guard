package com.volumeguard.xp.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.widget.FrameLayout;

import androidx.annotation.Nullable;

/**
 * 液态玻璃卡片：半透明着色 + 顶部高光渐变描边 + 可调圆角。
 * 配合 {@link AnimatedBackgroundView} 的背景模糊（API 31+ RenderEffect）
 * 形成"磨砂玻璃悬浮在流动渐变上"的液态玻璃质感。
 *
 * 所有视觉参数可经 {@link #applyAppearance} 运行时调节。
 */
public class GlassCard extends FrameLayout {

    private final Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint strokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();

    private int tint = 0xFF1B2440;
    private int alphaValue = AppConfig.DEFAULT_ALPHA;
    private float cornerPx = dp(28);
    private int highlight = AppConfig.DEFAULT_HIGHLIGHT;

    public GlassCard(Context context) { this(context, null); }
    public GlassCard(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }
    public GlassCard(Context context, @Nullable AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        setWillNotDraw(false);
        setBackground(null);
        int pad = (int) dp(18);
        setPadding(pad, pad, pad, pad);
        applyAppearance(tint, alphaValue, cornerPx, highlight);
    }

    /** 运行时调节外观。tint 为不透明色值，alphaValue 0~255，cornerPx 像素，highlight 0~100。 */
    public void applyAppearance(int tint, int alphaValue, float cornerPx, int highlight) {
        this.tint = tint;
        this.alphaValue = Math.max(0, Math.min(255, alphaValue));
        this.cornerPx = cornerPx;
        this.highlight = Math.max(0, Math.min(100, highlight));
        invalidate();
    }

    public void applyAppearanceDp(int tint, int alphaValue, float cornerDp, int highlight) {
        applyAppearance(tint, alphaValue, dp(cornerDp), highlight);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float inset = dp(1);
        rect.set(inset, inset, getWidth() - inset, getHeight() - inset);

        // 玻璃体：tint + 可调透明度
        int a = (tint >> 24) & 0xFF;
        fillPaint.setColor((tint & 0x00FFFFFF) | ((alphaValue * a / 255) << 24));
        canvas.drawRoundRect(rect, cornerPx, cornerPx, fillPaint);

        // 液态高光：左上→右下 白色渐变描边，强度可调
        int hi = 255 * highlight / 100;
        strokePaint.setShader(new LinearGradient(
                rect.left, rect.top, rect.right, rect.bottom,
                new int[]{0xFFFFFF & 0x00FFFFFF | (hi << 24), (hi / 3 << 24), 0x00FFFFFF},
                new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP));
        strokePaint.setStyle(Paint.Style.STROKE);
        strokePaint.setStrokeWidth(dp(1.4f));
        canvas.drawRoundRect(rect, cornerPx, cornerPx, strokePaint);
        strokePaint.setStyle(Paint.Style.FILL);
    }

    private float dp(float v) {
        return v * getResources().getDisplayMetrics().density;
    }
}
