package com.volumeguard.xp.ui;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;

import com.volumeguard.xp.R;
import com.volumeguard.xp.core.KeyNames;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;

/**
 * 主页：总开关 / 禁止按键管理 / 目标应用选择 / 液态玻璃外观自定义。
 */
public class MainActivity extends AppCompatActivity {

    private static final int REQ_PICK_APPS = 1001;

    private AppConfig cfg;

    private TextView statusText;
    private SwitchCompat enableSwitch;
    private LinearLayout keyList;
    private TextView appSummary;
    private AnimatedBackgroundView bg;

    private final int[] tintPresets = {
            0xFF1B2440, 0xFF0E2A3A, 0xFF241B40, 0xFF102818, 0xFF331B1B, 0xFF101014
    };

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        cfg = new AppConfig(this);

        bg = findViewById(R.id.bg);
        statusText = findViewById(R.id.statusText);
        enableSwitch = findViewById(R.id.enableSwitch);
        keyList = findViewById(R.id.keyList);
        appSummary = findViewById(R.id.appSummary);

        boolean active = ModuleStatus.isModuleActive();
        statusText.setText(active ? "● 模块已生效（Hook 运行中）" : "○ 模块未激活：请在 LSPosed 中启用并重启");
        statusText.setTextColor(active ? 0xFF6EE7A0 : 0xFFFFB4A2);

        // 总开关
        enableSwitch.setChecked(cfg.isEnabled());
        enableSwitch.setOnCheckedChangeListener((b, checked) -> {
            cfg.setEnabled(checked);
            cfg.save();
        });

        // 关于页
        Button aboutBtn = findViewById(R.id.aboutBtn);
        aboutBtn.setOnClickListener(v ->
                startActivity(new Intent(this, AboutActivity.class)));

        // 添加按键
        Button addKeyBtn = findViewById(R.id.addKeyBtn);
        addKeyBtn.setOnClickListener(v -> showAddKeyDialog());

        // 选择应用
        Button pickAppBtn = findViewById(R.id.pickAppBtn);
        pickAppBtn.setOnClickListener(v -> {
            Intent i = new Intent(this, AppPickerActivity.class);
            i.putStringArrayListExtra(AppPickerActivity.EXTRA_SELECTED,
                    new ArrayList<>(cfg.getApps()));
            startActivityForResult(i, REQ_PICK_APPS);
        });

        setupAppearanceControls();
        refreshAll();
    }

    // ---------------------------------------------------------------- 按键管理

    private void showAddKeyDialog() {
        List<KeyNames.Preset> presets = KeyNames.commonPresets();
        String[] items = new String[presets.size() + 1];
        for (int i = 0; i < presets.size(); i++) items[i] = presets.get(i).toString();
        items[presets.size()] = "自定义…（输入 KEYCODE 名称或数值）";

        new AlertDialog.Builder(this)
                .setTitle("添加禁止按键")
                .setItems(items, (d, which) -> {
                    if (which < presets.size()) {
                        addKey(presets.get(which).code);
                    } else {
                        showCustomKeyDialog();
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void showCustomKeyDialog() {
        EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        input.setHint("如 KEYCODE_VOLUME_UP 或 24");
        new AlertDialog.Builder(this)
                .setTitle("自定义按键")
                .setView(input)
                .setPositiveButton("添加", (d, w) -> {
                    int code = KeyNames.toCode(input.getText().toString());
                    if (code < 0) {
                        Toast.makeText(this, "无法识别，请输入有效的 KEYCODE 名称或非负数值", Toast.LENGTH_LONG).show();
                    } else {
                        addKey(code);
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void addKey(int code) {
        LinkedHashSet<Integer> keys = cfg.getKeys();
        if (!keys.add(code)) {
            Toast.makeText(this, "该按键已在列表中", Toast.LENGTH_SHORT).show();
            return;
        }
        cfg.setKeys(keys);
        cfg.save();
        refreshKeyList();
    }

    private void removeKey(int code) {
        LinkedHashSet<Integer> keys = cfg.getKeys();
        keys.remove(code);
        cfg.setKeys(keys);
        cfg.save();
        refreshKeyList();
    }

    private void refreshKeyList() {
        keyList.removeAllViews();
        LinkedHashSet<Integer> keys = cfg.getKeys();
        if (keys.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("（空）当前不拦截任何按键");
            empty.setTextColor(0xFF8A93A6);
            keyList.addView(empty);
            return;
        }
        for (int code : keys) {
            keyList.addView(buildChip(code));
        }
    }

    private View buildChip(int code) {
        TextView chip = new TextView(this);
        chip.setText(KeyNames.toName(code).replace("KEYCODE_", "") + "  (" + code + ")  ✕");
        chip.setTextColor(Color.WHITE);
        chip.setTextSize(14);
        int padH = (int) (12 * getResources().getDisplayMetrics().density);
        int padV = (int) (8 * getResources().getDisplayMetrics().density);
        chip.setPadding(padH, padV, padH, padV);
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(20 * getResources().getDisplayMetrics().density);
        g.setColor(0x3338BDF8);
        g.setStroke((int) (1 * getResources().getDisplayMetrics().density), 0x5538BDF8);
        chip.setBackground(g);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, padV, padV);
        lp.gravity = Gravity.START;
        chip.setLayoutParams(lp);
        chip.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setMessage("移除 " + KeyNames.toName(code) + " ？")
                .setPositiveButton("移除", (d, w) -> removeKey(code))
                .setNegativeButton("取消", null)
                .show());
        return chip;
    }

    // ---------------------------------------------------------------- 外观自定义

    private void setupAppearanceControls() {
        bindSeek(R.id.blurBar, R.id.blurVal, 0, 30, cfg.getBlur(),
                v -> { cfg.setBlur(v); cfg.save(); AppearanceManager.apply(bg.getRootView(), cfg); },
                v -> "模糊 " + String.format(java.util.Locale.CHINA, "%.0f", v));
        bindSeek(R.id.alphaBar, R.id.alphaVal, 30, 220, cfg.getAlpha(),
                v -> { cfg.setAlpha((int) v); cfg.save(); AppearanceManager.apply(bg.getRootView(), cfg); },
                v -> "透明度 " + (int) v);
        bindSeek(R.id.cornerBar, R.id.cornerVal, 8, 48, cfg.getCorner(),
                v -> { cfg.setCorner(v); cfg.save(); AppearanceManager.apply(bg.getRootView(), cfg); },
                v -> "圆角 " + String.format(java.util.Locale.CHINA, "%.0f", v) + "dp");
        bindSeek(R.id.highlightBar, R.id.highlightVal, 0, 100, cfg.getHighlight(),
                v -> { cfg.setHighlight((int) v); cfg.save(); AppearanceManager.apply(bg.getRootView(), cfg); },
                v -> "高光 " + (int) v + "%");

        LinearLayout tintRow = findViewById(R.id.tintRow);
        for (int color : tintPresets) {
            View dot = new View(this);
            int size = (int) (34 * getResources().getDisplayMetrics().density);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(size, size);
            lp.setMargins(0, 0, (int) (10 * getResources().getDisplayMetrics().density), 0);
            dot.setLayoutParams(lp);
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(color);
            g.setStroke((int) (2 * getResources().getDisplayMetrics().density), 0x66FFFFFF);
            dot.setBackground(g);
            String hex = String.format(java.util.Locale.CHINA, "#%06X", color & 0xFFFFFF);
            dot.setOnClickListener(v -> {
                cfg.setTint(hex);
                cfg.save();
                AppearanceManager.apply(bg.getRootView(), cfg);
            });
            tintRow.addView(dot);
        }

        SwitchCompat animSwitch = findViewById(R.id.animSwitch);
        animSwitch.setChecked(cfg.isAnimEnabled());
        animSwitch.setOnCheckedChangeListener((b, checked) -> {
            cfg.setAnimEnabled(checked);
            cfg.save();
            AppearanceManager.apply(bg.getRootView(), cfg);
        });

        Button resetBtn = findViewById(R.id.resetAppearanceBtn);
        resetBtn.setOnClickListener(v -> {
            cfg.resetAppearance();
            cfg.save();
            recreate();
        });
    }

    private interface OnSeekChanged { void onChanged(float value); }
    private interface LabelFormatter { String format(float value); }

    private void bindSeek(int barId, int labelId, int min, int max, float initial,
                          OnSeekChanged cb, LabelFormatter fmt) {
        SeekBar bar = findViewById(barId);
        TextView label = findViewById(labelId);
        bar.setMax(max - min);
        bar.setProgress(Math.round(initial) - min);
        label.setText(fmt.format(initial));
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                float v = progress + min;
                label.setText(fmt.format(v));
                if (fromUser) cb.onChanged(v);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });
    }

    // ---------------------------------------------------------------- 刷新 & 回调

    private void refreshAll() {
        refreshKeyList();
        LinkedHashSet<String> apps = cfg.getApps();
        appSummary.setText(apps.isEmpty()
                ? "（未选择）拦截不会作用于任何应用"
                : "已选 " + apps.size() + " 个应用：\n" + android.text.TextUtils.join("\n", apps));
        AppearanceManager.apply(bg.getRootView(), cfg);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_PICK_APPS && resultCode == RESULT_OK && data != null) {
            ArrayList<String> list = data.getStringArrayListExtra(AppPickerActivity.EXTRA_RESULT);
            if (list != null) {
                cfg.setApps(new LinkedHashSet<>(list));
                cfg.save();
            }
        }
        refreshAll();
    }

    @Override
    protected void onResume() {
        super.onResume();
        cfg.reload();
        enableSwitch.setChecked(cfg.isEnabled());
        refreshAll();
    }
}
