package com.volumeguard.xp.ui;

/**
 * 模块激活状态标记。默认 false；Xposed 生效时由 MainHook 将其恒置 true。
 * UI 据此显示"模块已生效 / 未激活"。
 */
public final class ModuleStatus {
    private ModuleStatus() {}

    public static boolean isModuleActive() {
        return false;
    }
}
