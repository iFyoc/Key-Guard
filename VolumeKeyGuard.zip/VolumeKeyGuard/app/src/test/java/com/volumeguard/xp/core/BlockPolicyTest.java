package com.volumeguard.xp.core;

import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * BlockPolicy：拦截决策的唯一事实来源（纯逻辑，Hook 端与 UI 端共用）。
 */
public class BlockPolicyTest {

    private static Map<String, String> baseMap() {
        Map<String, String> m = new HashMap<>();
        m.put("enabled", "1");
        m.put("keys", "24,25");
        m.put("apps", "com.target.app,com.other.app");
        return m;
    }

    @Test
    public void blocksListedKeyForTargetApp() {
        BlockPolicy p = BlockPolicy.fromMap(baseMap());
        assertTrue(p.blockKey("com.target.app", 24));
        assertTrue(p.blockKey("com.other.app", 25));
    }

    @Test
    public void doesNotBlockUnlistedKeyOrApp() {
        BlockPolicy p = BlockPolicy.fromMap(baseMap());
        assertFalse(p.blockKey("com.target.app", 4));   // BACK 不在列表
        assertFalse(p.blockKey("com.clean.app", 24));    // 应用未被选中
    }

    @Test
    public void doesNotBlockWhenDisabled() {
        Map<String, String> m = baseMap();
        m.put("enabled", "0");
        BlockPolicy p = BlockPolicy.fromMap(m);
        assertFalse(p.blockKey("com.target.app", 24));
        assertFalse(p.blockVolumeCall(new String[]{"com.target.app"}));
    }

    @Test
    public void blocksVolumeCallWhenAnyCallerPackageIsTarget() {
        BlockPolicy p = BlockPolicy.fromMap(baseMap());
        assertTrue(p.blockVolumeCall(new String[]{"com.target.app"}));
        assertFalse(p.blockVolumeCall(new String[]{"com.clean.app"}));
        assertFalse(p.blockVolumeCall(null));
        assertFalse(p.blockVolumeCall(new String[0]));
    }

    @Test
    public void missingKeysFallsBackToDefaultVolumeKeys() {
        Map<String, String> m = baseMap();
        m.remove("keys");
        BlockPolicy p = BlockPolicy.fromMap(m);
        assertTrue(p.blockKey("com.target.app", 24));   // VOLUME_UP
        assertTrue(p.blockKey("com.target.app", 25));   // VOLUME_DOWN
        assertTrue(p.blockKey("com.target.app", 164));  // VOLUME_MUTE
        assertFalse(p.blockKey("com.target.app", 26));  // POWER 不在默认集
    }

    @Test
    public void nullMapYieldsSafeDisabledPolicy() {
        BlockPolicy p = BlockPolicy.fromMap(null);
        assertFalse(p.blockKey("com.target.app", 24));
    }
}
