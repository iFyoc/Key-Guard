package com.volumeguard.xp.core;

import org.junit.jupiter.api.Test;

import java.util.LinkedHashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * ConfigCodec：配置以行式 key=value 文本持久化（SharedPreferences 存单字符串），
 * 必须能无损往返、容忍脏数据。
 */
public class ConfigCodecTest {

    @Test
    public void roundTripPreservesAllEntries() {
        Map<String, String> src = new LinkedHashMap<>();
        src.put("enabled", "1");
        src.put("keys", "24,25,164");
        src.put("apps", "com.foo.bar,com.baz.qux");
        src.put("ui_tint", "#202A44");
        String encoded = ConfigCodec.encode(src);
        Map<String, String> decoded = ConfigCodec.decode(encoded);
        assertEquals(src, decoded);
    }

    @Test
    public void decodeIgnoresBlankAndMalformedLines() {
        String raw = "\n# comment\nenabled=1\n\nbroken_line_without_eq\n\nkeys=24,25\n";
        Map<String, String> decoded = ConfigCodec.decode(raw);
        assertEquals(2, decoded.size());
        assertEquals("1", decoded.get("enabled"));
        assertEquals("24,25", decoded.get("keys"));
    }

    @Test
    public void decodeKeepsEmptyValueAndValueContainingEquals() {
        Map<String, String> decoded = ConfigCodec.decode("tint=\nexpr=a=b\n");
        assertEquals("", decoded.get("tint"));
        assertEquals("a=b", decoded.get("expr"));
    }

    @Test
    public void encodeSkipsNullValuesAndIsStable() {
        Map<String, String> src = new LinkedHashMap<>();
        src.put("b", "2");
        src.put("a", null);
        src.put("c", "3");
        String encoded = ConfigCodec.encode(src);
        assertTrue(encoded.contains("b=2"));
        assertTrue(encoded.contains("c=3"));
        assertTrue(!encoded.contains("a="));
        // 再次编解码保持稳定
        assertEquals(ConfigCodec.decode(encoded), ConfigCodec.decode(ConfigCodec.encode(ConfigCodec.decode(encoded))));
    }

    @Test
    public void decodeNullOrEmptyReturnsEmptyMap() {
        assertTrue(ConfigCodec.decode(null).isEmpty());
        assertTrue(ConfigCodec.decode("").isEmpty());
    }
}
