package com.volumeguard.xp.core;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * KeyNames：KEYCODE 名称与数值互转（UI 添加按键、配置解析共用）。
 */
public class KeyNamesTest {

    @Test
    public void resolvesKnownKeycodeNames() {
        assertEquals(24, KeyNames.toCode("KEYCODE_VOLUME_UP"));
        assertEquals(25, KeyNames.toCode("KEYCODE_VOLUME_DOWN"));
        assertEquals(164, KeyNames.toCode("KEYCODE_VOLUME_MUTE"));
        assertEquals(4, KeyNames.toCode("KEYCODE_BACK"));
        assertEquals(26, KeyNames.toCode("KEYCODE_POWER"));
        assertEquals(3, KeyNames.toCode("KEYCODE_HOME"));
    }

    @Test
    public void resolvesNumericStringsAndTrimmedInput() {
        assertEquals(24, KeyNames.toCode("24"));
        assertEquals(164, KeyNames.toCode(" 164 "));
        assertEquals(24, KeyNames.toCode(" KEYCODE_VOLUME_UP "));
    }

    @Test
    public void rejectsInvalidInput() {
        assertEquals(-1, KeyNames.toCode("KEYCODE_NOT_EXIST"));
        assertEquals(-1, KeyNames.toCode("abc"));
        assertEquals(-1, KeyNames.toCode(""));
        assertEquals(-1, KeyNames.toCode(null));
        assertEquals(-1, KeyNames.toCode("-5"));
    }

    @Test
    public void convertsCodeBackToName() {
        assertEquals("KEYCODE_VOLUME_UP", KeyNames.toName(24));
        assertEquals("KEYCODE_VOLUME_DOWN", KeyNames.toName(25));
        assertEquals("KEYCODE_VOLUME_MUTE", KeyNames.toName(164));
        // 未知 code 返回通用占位名
        assertEquals("KEYCODE_9999", KeyNames.toName(9999));
    }

    @Test
    public void commonPresetsContainVolumeKeysFirst() {
        assertTrue(KeyNames.commonPresets().size() >= 10);
        assertEquals(24, KeyNames.commonPresets().get(0).code);
        assertEquals(25, KeyNames.commonPresets().get(1).code);
        assertEquals(164, KeyNames.commonPresets().get(2).code);
    }
}
